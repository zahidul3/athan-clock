# Simple Docs for the Make Scripts.

This `ti_mini_openthread_linux_quickstart_guide.md` is intended to be very short and simple.
More details can be found in the (non-mini) ti_openthread_linux_quickstart_guide.md file.

* Step 1: Before starting, you must expand the SD Card Image.
  * See the quickstart guide for details.
* Step 2: Before starting, you should enable a long timeout for the sudo command.
  * See the quickstart guide for details.
* Step 3: Before starting, if you are using an c2538 with an RF06
  * Add the required commands to /etc/rc.local
  * See the quickstart guide for details.
* NOTE: This guide assumes your Beagle Bone Boots from the prepaired SD Card
  * See the quickstart guide for details.
* Step 4: Boot your Beagle Board.
* Step 5: Copy the 'ti_ot_linux_scripts.tar.gz' file to your beagle board home directory.
* Step 6: Unpack the 'ti_ot_linux_scripts.tar.gz' file. This produces a directory
  * In that directory is a `Makefile` and this `readme` file.
  * The makefile has a `make help` target that lists various targets.
* Step 7: Use the command: `make everything`
  * This will take 1 to 3 hours to complete
  * If the `apt-get` step fails, often corporate firewalls are problematic
    * You might try: At home, or via a celluar wifi hot spot. 
* Step 8: You must form a network.
  * Before creating a network, Edit `settings.mak`, and adjust settings per your needs.
  * Use the command: `make wpantund-form` to form (or create) a network.
  * You can erase/delete the network settings via `make wpantund-erase`
* Step 9: By default, the linux side of the network is not restarted at boot.
  * This step is optional
  * Edit the file: /etc/rc.local, and this command:
  * `make -C /path/to/dir/with/makefile at-boot`
  * Where `/path/to/dir/with/makefile` is the directory where the Makefile is located.
* Step 10: Or to start the linux side manually... 
  * Use the command: `make at-boot`
  * This will resume/recover the Linux side of the network.
